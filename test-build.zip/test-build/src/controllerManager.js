var controllerManager = {
  text: 'Hello World'
};